#ifndef _motermovement_H_
#define _motermovement_H_
#include <Arduino.h>
#include <moter.h>


class Motermovement{
  public:
    void set(Moter moter0, Moter moter1, Moter moter2, Moter moter3);
    void forward(int level);
    void back(int level);
    void cw(int level);
    void ccw(int level);
    void stop();

  private:
    Moter _moter0, _moter1, _moter2, _moter3;

};

#endif
