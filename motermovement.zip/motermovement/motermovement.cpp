#include <Arduino.h>
#include <moter.h>
#include "motermovement.h"

void Motermovement::set(Moter moter0, Moter moter1, Moter moter2, Moter moter3){
  _moter0 = moter0;
  _moter1 = moter1;
  _moter2 = moter2;
  _moter3 = moter3;
}

void Motermovement::forward(int level){
  _moter0.cw(level);
  _moter1.cw(level);
  _moter2.cw(level);
  _moter3.cw(level);
}

void Motermovement::back(int level){
  _moter0.ccw(level);
  _moter1.ccw(level);
  _moter2.ccw(level);
  _moter3.ccw(level);
}

void Motermovement::cw(int level){
  _moter0.cw(level);
  _moter1.cw(level);
  _moter2.ccw(level);
  _moter3.ccw(level);
}

void Motermovement::ccw(int level){
  _moter0.ccw(level);
  _moter1.ccw(level);
  _moter2.cw(level);
  _moter3.cw(level);
}

void Motermovement::stop(){
  _moter0.stop();
  _moter1.stop();
  _moter2.stop();
  _moter3.stop();
}
