#ifndef _moter_H_
#define _moter_H_
#include <Arduino.h>


class Moter{
  public:
    void set(uint8_t moter0, uint8_t moter1, uint8_t moter2, uint8_t moter3);
    void cw(uint8_t level);
    void ccw(uint8_t level);
    void stop();

  private:
    uint8_t _moter0, _moter1, _moter2, _moter3;

};

#endif
