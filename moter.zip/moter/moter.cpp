#include <Arduino.h>
#include "moter.h"

void Moter::set(uint8_t moter0, uint8_t moter1, uint8_t moter2, uint8_t moter3){
  _moter0 = moter0;
  _moter1 = moter1;
  _moter2 = moter2;
  _moter3 = moter3;

  pinMode(_moter0, OUTPUT);
  pinMode(_moter1, OUTPUT);
  pinMode(_moter2, OUTPUT);
  pinMode(_moter3, OUTPUT);

}

void Moter::cw(uint8_t level){
  analogWrite(_moter0, level);
  analogWrite(_moter1, level);
  analogWrite(_moter2, 0);
  analogWrite(_moter3, 0);
}

void Moter::ccw(uint8_t level){
  analogWrite(_moter0, 0);
  analogWrite(_moter1, 0);
  analogWrite(_moter2, level);
  analogWrite(_moter3, level);
}

void Moter::stop(){
  analogWrite(_moter0, 0);
  analogWrite(_moter1, 0);
  analogWrite(_moter2, 0);
  analogWrite(_moter3, 0);
}
